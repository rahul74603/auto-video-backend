var k=(t,l,e)=>new Promise((p,o)=>{var c=s=>{try{n(e.next(s))}catch(g){o(g)}},i=s=>{try{n(e.throw(s))}catch(g){o(g)}},n=s=>s.done?p(s.value):Promise.resolve(s.value).then(c,i);n((e=e.apply(t,l)).next())});import{r,j as a}from"./vendor-react-core-B82Rh6DQ.js";import{s as G}from"./storyRepository-DXJXS4B2.js";import{S as j}from"./index-Es6dO-RE.js";import{au as I,am as z}from"./vendor-others-BkM024ek.js";import{c as F,X as L,p as D,q as R,E as O}from"./vendor-icons-DaoopZi1.js";import"./vendor-firebase-core-DbDtGhu8.js";import"./vendor-firebase-auth-Dpdl4TGr.js";import"./vendor-firebase-storage-AsJYBKvf.js";function A(t){const[l,e]=r.useState(null),[p,o]=r.useState(!!t),[c,i]=r.useState(null);return r.useEffect(()=>{let n=!0;return t?(G.getBySlugOrId(t).then(s=>{n&&e(s)}).catch(s=>{n&&i(s)}).finally(()=>{n&&o(!1)}),()=>{n=!1}):()=>{n=!1}},[t]),{story:l,loading:p,error:c}}function P(t){if(!t)return new Date().toISOString();try{return t.toDate?t.toDate().toISOString():t.seconds?new Date(t.seconds*1e3).toISOString():new Date(t).toISOString()}catch(l){return new Date().toISOString()}}const $=["linear-gradient(135deg, #0f2027, #203a43, #2c5364)","linear-gradient(135deg, #1a0a00, #4a1500, #7c2d12)","linear-gradient(135deg, #001a00, #0a3300, #14532d)","linear-gradient(135deg, #1a0a2e, #2d1b69, #4c1d95)","linear-gradient(135deg, #0f0f1a, #1a1a3e, #1e3a8a)"];function B(t,l,e){if(!t)return"";switch(t.type){case"cover":return`
                <div class="cover-content">
                    <div class="badge">${t.badge||"📚 STUDYGYAAN"}</div>
                    <h1 class="cover-title">${t.title||""}</h1>
                    <p class="cover-sub">${t.subtitle||"StudyGyaan.in"}</p>
                    <div class="brand-tag">🌐 StudyGyaan.in</div>
                </div>`;case"stats":const p=(t.stats||[]).map(i=>`<div class="stat-card">
                    <span class="stat-icon">${i.icon}</span>
                    <span class="stat-val">${i.value}</span>
                    <span class="stat-lbl">${i.label}</span>
                </div>`).join("");return`
                <div class="slide-content">
                    <h2 class="slide-heading">${t.heading||""}</h2>
                    <div class="stats-grid">${p}</div>
                    <div class="brand-wm">StudyGyaan.in</div>
                </div>`;case"cta":const o=(t.lines||[]).map(i=>`<div class="cta-line">${i}</div>`).join("");return`
                <div class="slide-content">
                    <h2 class="cta-heading">${t.heading||""}</h2>
                    <div class="cta-box">${o}</div>
                    <a href="${l}" class="cta-btn">
                        ${t.ctaText||"Visit Now"} →
                    </a>
                    <div class="brand-wm">StudyGyaan.in</div>
                </div>`;default:const c=(t.lines||[]).map(i=>`<div class="info-line">${i}</div>`).join("");return`
                <div class="slide-content">
                    <h2 class="slide-heading">${t.heading||""}</h2>
                    <div class="lines-box">${c}</div>
                    <div class="brand-wm">StudyGyaan.in</div>
                </div>`}}function W(t,l){const e=t.title||"StudyGyaan Update",p=t.slug||l,o=t.coverImage||"https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?w=720&h=1280&fit=crop",c=t.applyLink||"https://studygyaan.in",i=String(t.storyType||"mocktest").toLowerCase(),n=i==="blog"?"#059669":"#2563eb";let s=t.slides;(!s||s.length<3)&&(i==="blog"?s=[{type:"cover",title:e,subtitle:t.category||"Education",badge:"📝 NEW BLOG POST"},{type:"info",heading:"📌 About This Article",lines:[`📁 ${t.category||"Education"}`,`✍️ ${t.author||"Rahul Sir"}`,"🌐 StudyGyaan.in","📅 Latest 2025 Update"]},{type:"content",heading:"✅ Key Highlights",lines:["• Complete & Accurate Information","• Easy Hindi Explanation","• Free PDF Download Available","• Updated for 2025 Exams"]},{type:"content",heading:"📚 Why Read This?",lines:["• Exam-Focused Content","• Important for Govt Exams","• Short & Clear Format","• Expert Written"]},{type:"cta",heading:"🚀 Read Full Article FREE!",lines:["✅ Free PDF Notes","✅ Online Mock Tests","✅ Daily Updates"],ctaText:"Read Full Article",ctaLink:c}]:s=[{type:"cover",title:e,subtitle:`${t.subject||"GK"} Mock Test`,badge:"🎯 FREE MOCK TEST"},{type:"stats",heading:"📊 Test Overview",stats:[{icon:"📝",value:String(t.questions||"50"),label:"Questions"},{icon:"⏱️",value:String(t.duration||"30"),label:"Minutes"},{icon:"🏆",value:"FREE",label:"Cost"},{icon:"📱",value:"Online",label:"Mode"}]},{type:"content",heading:"📚 Topics Covered",lines:["• Important Expected MCQs","• Previous Year Questions","• Bilingual Hindi + English","• With Timer & Explanation"]},{type:"content",heading:"🎯 Best For These Exams",lines:["• SSC CGL, CHSL 2025","• RRB NTPC, Group D 2025","• Bank PO, Clerk 2025","• Police & State Exams 2025"]},{type:"cta",heading:"🚀 Attempt FREE Now!",lines:["✅ No Registration Required","✅ Instant Result & Score","✅ Free Certificate"],ctaText:"Start Test FREE",ctaLink:c}]);const g=s.map((m,b)=>{const d=b===0?"page-cover":`page-${b+1}`,h=$[b%$.length],f=m.type==="cta"?"8s":"6s",w=B(m,c,b===s.length-1),S=b===s.length-1;let x="";return b===0?x=`
                <amp-story-grid-layer template="fill">
                    <amp-img
                        src="${o}"
                        width="720"
                        height="1280"
                        layout="responsive"
                        alt="${e}">
                    </amp-img>
                </amp-story-grid-layer>
                <amp-story-grid-layer template="fill">
                    <div class="overlay-dark"></div>
                </amp-story-grid-layer>`:x=`
                <amp-story-grid-layer template="fill">
                    <div style="background:${h};width:100%;height:100%;"></div>
                </amp-story-grid-layer>`,`
        <amp-story-page id="${d}" auto-advance-after="${f}">
            ${x}
            <amp-story-grid-layer template="vertical">
                ${w}
            </amp-story-grid-layer>
            ${S?`
            <amp-story-page-outlink layout="nodisplay">
                <a href="${c}">Visit StudyGyaan.in</a>
            </amp-story-page-outlink>`:""}
        </amp-story-page>`}).join(`
`),v=JSON.stringify({bookendVersion:"v1.0",shareProviders:[{provider:"whatsapp"},{provider:"twitter"},{provider:"facebook"},{provider:"system"}],components:[{type:"heading",text:"More from StudyGyaan"},{type:"small",title:"Free Mock Tests & PDF Notes",url:"https://studygyaan.in",image:o},{type:"cta-link",links:[{text:"🌐 Visit StudyGyaan.in",url:"https://studygyaan.in"}]}]}),y=`
        body { font-family: 'Segoe UI', sans-serif; margin: 0; }
        amp-story { color: white; }

        .overlay-dark {
            background: linear-gradient(to bottom, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.85) 100%);
            width: 100%; height: 100%;
        }

        /* Cover */
        .cover-content {
            position: absolute;
            bottom: 80px; left: 0; right: 0;
            padding: 0 24px;
        }
        .badge {
            color: white;
            background: ${n};
            padding: 8px 16px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 900;
            display: inline-block;
            margin-bottom: 16px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .cover-title {
            font-size: 28px;
            font-weight: 900;
            line-height: 1.2;
            margin: 0 0 12px 0;
            text-shadow: 2px 2px 8px rgba(0,0,0,0.9);
        }
        .cover-sub {
            font-size: 16px;
            color: #fbbf24;
            font-weight: 700;
            margin: 0 0 14px 0;
        }
        .brand-tag {
            background: rgba(255,255,255,0.15);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 700;
            display: inline-block;
        }

        /* Info/Content Slides */
        .slide-content {
            padding: 40px 20px 80px 20px;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .slide-heading {
            font-size: 22px;
            font-weight: 900;
            color: #fbbf24;
            margin: 0 0 20px 0;
            border-bottom: 3px solid rgba(251,191,36,0.4);
            padding-bottom: 10px;
        }
        .lines-box {
            background: rgba(0,0,0,0.4);
            border-radius: 16px;
            padding: 16px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .info-line {
            font-size: 16px;
            font-weight: 700;
            color: #f1f5f9;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .info-line:last-child { border-bottom: none; }

        /* Stats */
        .stats-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 8px;
        }
        .stat-card {
            flex: 1;
            min-width: 80px;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 14px;
            padding: 14px 6px;
            text-align: center;
        }
        .stat-icon { font-size: 24px; display: block; margin-bottom: 6px; }
        .stat-val { font-size: 20px; font-weight: 900; color: #fbbf24; display: block; }
        .stat-lbl { font-size: 10px; color: #cbd5e1; text-transform: uppercase; font-weight: 700; }

        /* CTA */
        .cta-heading {
            font-size: 24px;
            font-weight: 900;
            color: #fff;
            margin: 0 0 16px 0;
            text-align: center;
        }
        .cta-box {
            background: rgba(255,255,255,0.1);
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 20px;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .cta-line {
            font-size: 16px;
            font-weight: 700;
            color: #a7f3d0;
            padding: 6px 0;
        }
        .cta-btn {
            display: block;
            background: linear-gradient(135deg, #f59e0b, #ef4444);
            color: white;
            text-decoration: none;
            padding: 14px 20px;
            border-radius: 50px;
            font-size: 18px;
            font-weight: 900;
            text-align: center;
            box-shadow: 0 8px 24px rgba(0,0,0,0.4);
        }

        /* Brand Watermark */
        .brand-wm {
            position: absolute;
            bottom: 16px; right: 16px;
            font-size: 11px;
            color: rgba(255,255,255,0.4);
            font-weight: 700;
        }
    `;return`<!doctype html>
<html amp lang="hi">
<head>
    <meta charset="utf-8">
    <script async src="https://cdn.ampproject.org/v0.js"><\/script>
    <script async custom-element="amp-story"
        src="https://cdn.ampproject.org/v0/amp-story-1.0.js"><\/script>
    <title>${e}</title>
    <link rel="canonical" href="https://studygyaan.in/web-stories/${p}">
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
    <style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style>
    <noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
    <style amp-custom>${y}</style>
</head>
<body>
    <amp-story
        standalone
        title="${e}"
        publisher="StudyGyaan"
        publisher-logo-src="https://studygyaan.in/logo.png"
        poster-portrait-src="${o}">

        ${g}

        <amp-story-bookend layout="nodisplay">
            <script type="application/json">
                ${v}
            <\/script>
        </amp-story-bookend>

    </amp-story>
</body>
</html>`}const _=()=>{const{id:t}=I(),l=z(),[e,p]=r.useState(null),[o,c]=r.useState(null),[i,n]=r.useState(!0),[s,g]=r.useState(!1),[v,y]=r.useState(!1),[m,b]=r.useState(null),{story:d,loading:h,error:f}=A(t);r.useEffect(()=>{if(n(h),!t||f){g(!0);return}d!=null&&d.id&&(g(!1),p(d),b(d.id),c(W(d,d.id)))},[t,d,h,f]);const w=r.useCallback(()=>k(null,null,function*(){const u=`https://studygyaan.in/web-stories/${m||t}`,T=(e==null?void 0:e.title)||"StudyGyaan Web Story";if(navigator.share)try{yield navigator.share({title:T,url:u});return}catch(C){}try{yield navigator.clipboard.writeText(u),y(!0),setTimeout(()=>y(!1),3e3)}catch(C){}}),[e,m,t]),S=r.useCallback(()=>{window.history.length>1?l(-1):l("/web-stories")},[l]);if(i)return a.jsxs("div",{className:"h-screen w-screen flex flex-col items-center justify-center bg-black text-white",children:[a.jsx(F,{className:"w-10 h-10 animate-spin text-blue-500 mb-4"}),a.jsx("p",{className:"font-black uppercase tracking-widest text-xs",children:"Story Load हो रही है..."})]});if(s||!o)return a.jsxs(a.Fragment,{children:[a.jsx(j,{customTitle:"Story Not Found | StudyGyaan",noIndex:!0}),a.jsxs("div",{className:"h-screen w-screen flex flex-col items-center justify-center bg-black text-white gap-4",children:[a.jsx("div",{className:"text-5xl",children:"😔"}),a.jsx("h1",{className:"text-xl font-black",children:"Story नहीं मिली!"}),a.jsx("a",{href:"/web-stories",className:"bg-blue-600 text-white px-6 py-3 rounded-xl font-black text-sm hover:bg-blue-700 transition-all",children:"सभी Stories देखें →"})]})]});const E=`https://studygyaan.in/web-stories/${e.slug||m||t}`,N=P(e.createdAt);return a.jsxs("div",{className:"h-screen w-screen bg-black flex justify-center items-center fixed inset-0 z-[9999]",children:[a.jsx(j,{customTitle:`${e.title} | Web Story | StudyGyaan`,customDescription:e.description||`${e.title} - StudyGyaan Web Story पर पढ़ें।`,customUrl:E,customImage:e.coverImage||"https://studygyaan.in/og-image.jpg",customKeywords:`${e.title}, Web Story, StudyGyaan, ${e.category||"Education"}`,ogType:"article",publishedDate:N,author:e.author||"StudyGyaan",category:e.category||"Education"}),a.jsx("iframe",{srcDoc:o,className:"w-full h-full max-w-[450px] border-none bg-black shadow-2xl",title:e.title,sandbox:"allow-scripts allow-same-origin allow-popups allow-forms allow-top-navigation allow-top-navigation-by-user-activation",loading:"eager"}),a.jsxs("div",{className:"absolute top-4 right-4 flex flex-col gap-2 z-[10000]",children:[a.jsx("button",{onClick:S,className:"p-2 bg-white/10 hover:bg-red-500 rounded-full text-white transition-all border border-white/20 backdrop-blur-md","aria-label":"Story बंद करें",children:a.jsx(L,{size:22})}),a.jsx("button",{onClick:w,className:"p-2 bg-white/10 hover:bg-blue-500 rounded-full text-white transition-all border border-white/20 backdrop-blur-md","aria-label":"Share करें",children:v?a.jsx(D,{size:22,className:"text-green-400"}):a.jsx(R,{size:22})})]}),a.jsx("div",{className:"absolute bottom-0 left-0 right-0 max-w-[450px] mx-auto",children:a.jsxs("a",{href:e.applyLink||"/",target:"_blank",rel:"noopener noreferrer",className:"flex items-center justify-between px-5 py-3 bg-gradient-to-r from-blue-600 to-indigo-700 text-white font-black text-sm hover:from-blue-700 transition-all",children:[a.jsx("span",{children:e.storyType==="blog"?"📝 Full Blog पढ़ें":"🎯 Test Attempt करें"}),a.jsx(O,{size:18})]})}),a.jsx("nav",{className:"absolute bottom-14 left-0 right-0 max-w-[450px] mx-auto px-3 pb-2","aria-label":"Related Links",children:a.jsx("div",{className:"flex gap-2 overflow-x-auto scrollbar-hide",children:[{href:"/govt-jobs",label:"🏛️ Jobs"},{href:"/test",label:"📝 Tests"},{href:"/blog",label:"📰 Blogs"},{href:"/free-study-material",label:"📚 Notes"}].map(u=>a.jsx("a",{href:u.href,className:"shrink-0 bg-white/10 text-white text-[10px] font-black px-3 py-1.5 rounded-full border border-white/20 hover:bg-white/20 transition-all backdrop-blur-sm whitespace-nowrap",children:u.label},u.href))})})]})};export{_ as default};
