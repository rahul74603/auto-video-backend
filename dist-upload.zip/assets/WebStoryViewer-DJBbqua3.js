var k=(t,r,s)=>new Promise((o,n)=>{var l=i=>{try{e(s.next(i))}catch(g){n(g)}},c=i=>{try{e(s.throw(i))}catch(g){n(g)}},e=i=>i.done?o(i.value):Promise.resolve(i.value).then(l,c);e((s=s.apply(t,r)).next())});import{r as p,j as a}from"./vendor-react-core-B82Rh6DQ.js";import{s as E}from"./storyRepository-BAitGAXS.js";import{S}from"./index-DI5P6o-G.js";import{t as N}from"./firestore-CQuP4-Lc.js";import{au as T,am as C}from"./vendor-others-BkM024ek.js";import{c as G,X as z,p as F,q as I,E as L}from"./vendor-icons-z75ETtNn.js";import"./vendor-firebase-core-Cq4LNYCs.js";import"./vendor-firebase-auth-CrOCFmkA.js";import"./vendor-firebase-storage-CwwDoimU.js";function R(t){const[r,s]=p.useState(null),[o,n]=p.useState(!!t),[l,c]=p.useState(null);return p.useEffect(()=>{let e=!0;return t?(E.getBySlugOrId(t).then(i=>{e&&s(i)}).catch(i=>{e&&c(i)}).finally(()=>{e&&n(!1)}),()=>{e=!1}):()=>{e=!1}},[t]),{story:r,loading:o,error:l}}function A(t){return(N(t)||new Date).toISOString()}const j=["linear-gradient(135deg, #0f2027, #203a43, #2c5364)","linear-gradient(135deg, #1a0a00, #4a1500, #7c2d12)","linear-gradient(135deg, #001a00, #0a3300, #14532d)","linear-gradient(135deg, #1a0a2e, #2d1b69, #4c1d95)","linear-gradient(135deg, #0f0f1a, #1a1a3e, #1e3a8a)"];function D(t,r){switch(t.type){case"cover":return`
                <div class="cover-content">
                    <div class="badge">${t.badge||"📚 STUDYGYAAN"}</div>
                    <h1 class="cover-title">${t.title||""}</h1>
                    <p class="cover-sub">${t.subtitle||"StudyGyaan.in"}</p>
                    <div class="brand-tag">🌐 StudyGyaan.in</div>
                </div>`;case"stats":{const s=(t.stats||[]).map(o=>`<div class="stat-card">
                    <span class="stat-icon">${o.icon}</span>
                    <span class="stat-val">${o.value}</span>
                    <span class="stat-lbl">${o.label}</span>
                </div>`).join("");return`
                <div class="slide-content">
                    <h2 class="slide-heading">${t.heading||""}</h2>
                    <div class="stats-grid">${s}</div>
                    <div class="brand-wm">StudyGyaan.in</div>
                </div>`}case"cta":{const s=(t.lines||[]).map(o=>`<div class="cta-line">${o}</div>`).join("");return`
                <div class="slide-content">
                    <h2 class="cta-heading">${t.heading||""}</h2>
                    <div class="cta-box">${s}</div>
                    <a href="${r}" class="cta-btn">
                        ${t.ctaText||"Visit Now"} →
                    </a>
                    <div class="brand-wm">StudyGyaan.in</div>
                </div>`}default:{const s=(t.lines||[]).map(o=>`<div class="info-line">${o}</div>`).join("");return`
                <div class="slide-content">
                    <h2 class="slide-heading">${t.heading||""}</h2>
                    <div class="lines-box">${s}</div>
                    <div class="brand-wm">StudyGyaan.in</div>
                </div>`}}}function P(t,r){const s=t.title||"StudyGyaan Update",o=t.slug||r,n=t.coverImage||"https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?w=720&h=1280&fit=crop",l=t.applyLink||"https://studygyaan.in",c=String(t.storyType||"mocktest").toLowerCase(),e=c==="blog"?"#059669":"#2563eb";let i=t.slides;(!i||i.length<3)&&(c==="blog"?i=[{type:"cover",title:s,subtitle:t.category||"Education",badge:"📝 NEW BLOG POST"},{type:"info",heading:"📌 About This Article",lines:[`📁 ${t.category||"Education"}`,`✍️ ${t.author||"StudyGyaan Editorial Team"}`,"🌐 StudyGyaan.in","📅 Latest 2025 Update"]},{type:"content",heading:"✅ Key Highlights",lines:["• Complete & Accurate Information","• Easy Hindi Explanation","• Free PDF Download Available","• Updated for 2025 Exams"]},{type:"content",heading:"📚 Why Read This?",lines:["• Exam-Focused Content","• Important for Govt Exams","• Short & Clear Format","• Expert Written"]},{type:"cta",heading:"🚀 Read Full Article FREE!",lines:["✅ Free PDF Notes","✅ Online Mock Tests","✅ Daily Updates"],ctaText:"Read Full Article",ctaLink:l}]:i=[{type:"cover",title:s,subtitle:`${t.subject||"GK"} Mock Test`,badge:"🎯 FREE MOCK TEST"},{type:"stats",heading:"📊 Test Overview",stats:[{icon:"📝",value:String(t.questions||"50"),label:"Questions"},{icon:"⏱️",value:String(t.duration||"30"),label:"Minutes"},{icon:"🏆",value:"FREE",label:"Cost"},{icon:"📱",value:"Online",label:"Mode"}]},{type:"content",heading:"📚 Topics Covered",lines:["• Important Expected MCQs","• Previous Year Questions","• Bilingual Hindi + English","• With Timer & Explanation"]},{type:"content",heading:"🎯 Best For These Exams",lines:["• SSC CGL, CHSL 2025","• RRB NTPC, Group D 2025","• Bank PO, Clerk 2025","• Police & State Exams 2025"]},{type:"cta",heading:"🚀 Attempt FREE Now!",lines:["✅ No Registration Required","✅ Instant Result & Score","✅ Free Certificate"],ctaText:"Start Test FREE",ctaLink:l}]);const g=i.map((h,b)=>{const w=b===0?"page-cover":`page-${b+1}`,f=j[b%j.length],v=h.type==="cta"?"8s":"6s",u=D(h,l),d=b===i.length-1;let m="";return b===0?m=`
                <amp-story-grid-layer template="fill">
                    <amp-img
                        src="${n}"
                        width="720"
                        height="1280"
                        layout="responsive"
                        alt="${s}">
                    </amp-img>
                </amp-story-grid-layer>
                <amp-story-grid-layer template="fill">
                    <div class="overlay-dark"></div>
                </amp-story-grid-layer>`:m=`
                <amp-story-grid-layer template="fill">
                    <div style="background:${f};width:100%;height:100%;"></div>
                </amp-story-grid-layer>`,`
        <amp-story-page id="${w}" auto-advance-after="${v}">
            ${m}
            <amp-story-grid-layer template="vertical">
                ${u}
            </amp-story-grid-layer>
            ${d?`
            <amp-story-page-outlink layout="nodisplay">
                <a href="${l}">Visit StudyGyaan.in</a>
            </amp-story-page-outlink>`:""}
        </amp-story-page>`}).join(`
`),x=JSON.stringify({bookendVersion:"v1.0",shareProviders:[{provider:"whatsapp"},{provider:"twitter"},{provider:"facebook"},{provider:"system"}],components:[{type:"heading",text:"More from StudyGyaan"},{type:"small",title:"Free Mock Tests & PDF Notes",url:"https://studygyaan.in",image:n},{type:"cta-link",links:[{text:"🌐 Visit StudyGyaan.in",url:"https://studygyaan.in"}]}]}),y=`
        body { font-family: 'Segoe UI', sans-serif; margin: 0; }
        amp-story { color: white; }

        .overlay-dark {
            background: linear-gradient(to bottom, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.85) 100%);
            width: 100%; height: 100%;
        }

        /* Cover */
        .cover-content {
            position: absolute;
            bottom: 80px; left: 0; right: 0;
            padding: 0 24px;
        }
        .badge {
            color: white;
            background: ${e};
            padding: 8px 16px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 900;
            display: inline-block;
            margin-bottom: 16px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .cover-title {
            font-size: 28px;
            font-weight: 900;
            line-height: 1.2;
            margin: 0 0 12px 0;
            text-shadow: 2px 2px 8px rgba(0,0,0,0.9);
        }
        .cover-sub {
            font-size: 16px;
            color: #fbbf24;
            font-weight: 700;
            margin: 0 0 14px 0;
        }
        .brand-tag {
            background: rgba(255,255,255,0.15);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 700;
            display: inline-block;
        }

        /* Info/Content Slides */
        .slide-content {
            padding: 40px 20px 80px 20px;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .slide-heading {
            font-size: 22px;
            font-weight: 900;
            color: #fbbf24;
            margin: 0 0 20px 0;
            border-bottom: 3px solid rgba(251,191,36,0.4);
            padding-bottom: 10px;
        }
        .lines-box {
            background: rgba(0,0,0,0.4);
            border-radius: 16px;
            padding: 16px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .info-line {
            font-size: 16px;
            font-weight: 700;
            color: #f1f5f9;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .info-line:last-child { border-bottom: none; }

        /* Stats */
        .stats-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 8px;
        }
        .stat-card {
            flex: 1;
            min-width: 80px;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 14px;
            padding: 14px 6px;
            text-align: center;
        }
        .stat-icon { font-size: 24px; display: block; margin-bottom: 6px; }
        .stat-val { font-size: 20px; font-weight: 900; color: #fbbf24; display: block; }
        .stat-lbl { font-size: 10px; color: #cbd5e1; text-transform: uppercase; font-weight: 700; }

        /* CTA */
        .cta-heading {
            font-size: 24px;
            font-weight: 900;
            color: #fff;
            margin: 0 0 16px 0;
            text-align: center;
        }
        .cta-box {
            background: rgba(255,255,255,0.1);
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 20px;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .cta-line {
            font-size: 16px;
            font-weight: 700;
            color: #a7f3d0;
            padding: 6px 0;
        }
        .cta-btn {
            display: block;
            background: linear-gradient(135deg, #f59e0b, #ef4444);
            color: white;
            text-decoration: none;
            padding: 14px 20px;
            border-radius: 50px;
            font-size: 18px;
            font-weight: 900;
            text-align: center;
            box-shadow: 0 8px 24px rgba(0,0,0,0.4);
        }

        /* Brand Watermark */
        .brand-wm {
            position: absolute;
            bottom: 16px; right: 16px;
            font-size: 11px;
            color: rgba(255,255,255,0.4);
            font-weight: 700;
        }
    `;return`<!doctype html>
<html amp lang="hi">
<head>
    <meta charset="utf-8">
    <script async src="https://cdn.ampproject.org/v0.js"><\/script>
    <script async custom-element="amp-story"
        src="https://cdn.ampproject.org/v0/amp-story-1.0.js"><\/script>
    <title>${s}</title>
    <link rel="canonical" href="https://studygyaan.in/web-stories/${o}">
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
    <style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style>
    <noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
    <style amp-custom>${y}</style>
</head>
<body>
    <amp-story
        standalone
        title="${s}"
        publisher="StudyGyaan"
        publisher-logo-src="https://studygyaan.in/logo.png"
        poster-portrait-src="${n}">

        ${g}

        <amp-story-bookend layout="nodisplay">
            <script type="application/json">
                ${x}
            <\/script>
        </amp-story-bookend>

    </amp-story>
</body>
</html>`}const Q=()=>{var u;const{id:t}=T(),r=C(),[s,o]=p.useState(!1),{story:n,loading:l,error:c}=R(t),e=n,i=(u=n==null?void 0:n.id)!=null?u:null,g=l,x=!!(!t||c)||!l&&!(n!=null&&n.id),y=p.useMemo(()=>e&&i?P(e,i):null,[e,i]),h=p.useCallback(()=>k(null,null,function*(){const d=`https://studygyaan.in/web-stories/${i||t}`,m=(e==null?void 0:e.title)||"StudyGyaan Web Story";if(navigator.share)try{yield navigator.share({title:m,url:d});return}catch($){}try{yield navigator.clipboard.writeText(d),o(!0),setTimeout(()=>o(!1),3e3)}catch($){}}),[e,i,t]),b=p.useCallback(()=>{window.history.length>1?r(-1):r("/web-stories")},[r]);if(g)return a.jsxs("div",{className:"h-screen w-screen flex flex-col items-center justify-center bg-black text-white",children:[a.jsx(G,{className:"w-10 h-10 animate-spin text-blue-500 mb-4"}),a.jsx("p",{className:"font-black uppercase tracking-widest text-xs",children:"Story Load हो रही है..."})]});if(x||!y||!e)return a.jsxs(a.Fragment,{children:[a.jsx(S,{customTitle:"Story Not Found | StudyGyaan",noIndex:!0}),a.jsxs("div",{className:"h-screen w-screen flex flex-col items-center justify-center bg-black text-white gap-4",children:[a.jsx("div",{className:"text-5xl",children:"😔"}),a.jsx("h1",{className:"text-xl font-black",children:"Story नहीं मिली!"}),a.jsx("a",{href:"/web-stories",className:"bg-blue-600 text-white px-6 py-3 rounded-xl font-black text-sm hover:bg-blue-700 transition-all",children:"सभी Stories देखें →"})]})]});const f=`https://studygyaan.in/web-stories/${e.slug||i||t}`,v=A(e.createdAt);return a.jsxs("div",{className:"h-screen w-screen bg-black flex justify-center items-center fixed inset-0 z-[9999]",children:[a.jsx(S,{customTitle:`${e.title} | Web Story | StudyGyaan`,customDescription:e.description||`${e.title} - StudyGyaan Web Story पर पढ़ें।`,customUrl:f,customImage:e.coverImage||"https://studygyaan.in/og-image.jpg",customKeywords:`${e.title}, Web Story, StudyGyaan, ${e.category||"Education"}`,ogType:"article",publishedDate:v,author:e.author||"StudyGyaan",category:e.category||"Education"}),a.jsx("iframe",{srcDoc:y,className:"w-full h-full max-w-[450px] border-none bg-black shadow-2xl",title:e.title,sandbox:"allow-scripts allow-same-origin allow-popups allow-forms allow-top-navigation allow-top-navigation-by-user-activation",loading:"eager"}),a.jsxs("div",{className:"absolute top-4 right-4 flex flex-col gap-2 z-[10000]",children:[a.jsx("button",{onClick:b,className:"p-2 bg-white/10 hover:bg-red-500 rounded-full text-white transition-all border border-white/20 backdrop-blur-md","aria-label":"Story बंद करें",children:a.jsx(z,{size:22})}),a.jsx("button",{onClick:h,className:"p-2 bg-white/10 hover:bg-blue-500 rounded-full text-white transition-all border border-white/20 backdrop-blur-md","aria-label":"Share करें",children:s?a.jsx(F,{size:22,className:"text-green-400"}):a.jsx(I,{size:22})})]}),a.jsx("div",{className:"absolute bottom-0 left-0 right-0 max-w-[450px] mx-auto",children:a.jsxs("a",{href:e.applyLink||"/",target:"_blank",rel:"noopener noreferrer",className:"flex items-center justify-between px-5 py-3 bg-gradient-to-r from-blue-600 to-indigo-700 text-white font-black text-sm hover:from-blue-700 transition-all",children:[a.jsx("span",{children:e.storyType==="blog"?"📝 Full Blog पढ़ें":"🎯 Test Attempt करें"}),a.jsx(L,{size:18})]})}),a.jsx("nav",{className:"absolute bottom-14 left-0 right-0 max-w-[450px] mx-auto px-3 pb-2","aria-label":"Related Links",children:a.jsx("div",{className:"flex gap-2 overflow-x-auto scrollbar-hide",children:[{href:"/govt-jobs",label:"🏛️ Jobs"},{href:"/test",label:"📝 Tests"},{href:"/blog",label:"📰 Blogs"},{href:"/free-study-material",label:"📚 Notes"}].map(d=>a.jsx("a",{href:d.href,className:"shrink-0 bg-white/10 text-white text-[10px] font-black px-3 py-1.5 rounded-full border border-white/20 hover:bg-white/20 transition-all backdrop-blur-sm whitespace-nowrap",children:d.label},d.href))})})]})};export{Q as default};
